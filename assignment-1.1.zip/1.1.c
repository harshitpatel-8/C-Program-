#include<stdio.h>
int main()
{
    int a,b,c;
    a=10;
    b=20;
    c=a+b;
    printf("Add is %d\n ", c);

}
