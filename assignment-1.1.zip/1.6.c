#include<stdio.h>
int main()
{
    int hours;
    int minutes;
    printf("enter hours:");
    scanf("%d", &hours);
    minutes=hours*60;
    printf("minutes %d\n", minutes);
}
