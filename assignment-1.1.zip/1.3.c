#include<stdio.h>
int main()
{
    int a,b,y;
    a=10;
    b=20;
    y=a*b;
    printf("multiply is %d\n ", y);
}
