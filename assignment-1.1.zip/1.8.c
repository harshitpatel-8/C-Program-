#include<stdio.h>
int main()
{
    int dollors;
    int Rs;
    printf("enter dollors:");
    scanf("%d", &dollors);
    Rs=dollors*48;
    printf("Rs %d\n", Rs);

}
