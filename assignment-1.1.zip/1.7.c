#include<stdio.h>
int main()
{
    int hours;
    int minutes;
    printf("Enter minutes:");
    scanf("%d",&minutes);
    hours = minutes/60;
    printf("hours %d\n",hours);

}
