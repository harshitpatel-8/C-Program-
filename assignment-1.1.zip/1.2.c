#include<stdio.h>
int main()
{
    int a, b, x;
     a=10;
    b=20;
    x=a-b;
    printf("subtract is %d\n ", x);

}
