#include<stdio.h>
int main()
{
    int a,b,z;
    a=10;
    b=20;
    z=b/a;
    printf("divide is %d\n ", z);

}
