#include<stdio.h>
int main()
{
    int dollors;
    int Rs;
    printf("enter Rs:");
    scanf("%d", &Rs);
    dollors=Rs/48;
    printf("dollors %d\n", dollors);
}
