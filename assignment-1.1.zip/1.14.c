#include<stdio.h>
int main()
{
     int  celsius,fahrenheit;
    printf("Enter celsius:");
    scanf("%d",&celsius);
    fahrenheit = ((9.0/5) * celsius) + 32;
    printf("fahrenheit %d\n",fahrenheit);

}
