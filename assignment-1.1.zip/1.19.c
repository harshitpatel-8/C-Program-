#include<stdio.h>
int main()
{
    int radius,area;
    printf("Enter radius:");
    scanf("%d",&radius);
    area = 22.0/7 * radius * radius;
    printf("area of circle %d\n",area);

}
